# Bug Report Raw Data




Data Overview (compression format: .tar.bz2, file format: .xml)

No | Project | # of Reports | Size | Period
-- | ------- | ------------ | ---- | ------
1 | [Eclipse](https://drive.google.com/open?id=1m1fOrLrbz-soboYytPULxyXyF6Kcjk4J) | 528,862 | 387MB | 10/10/01 - 09/30/18
2 | [Freedesktop](https://drive.google.com/open?id=1A5VtVuWM0ZH7W4KzR66ihMDYW8PjBVO_) | 106,065 | 121MB | 01/09/03 - 09/30/18
3 | [GCC](https://drive.google.com/open?id=11tDoW2Aq-1Nu6nq2cCVbzSoNrUesYOf9) | 81,463 | 113MB | 08/03/99 - 09/30/18
4 | [GNOME](https://drive.google.com/open?id=1L8xDyGENXi788xThklDSGyYGKSbIFOWi) | 673,301 | 649MB | 02/05/99 - 09/30/18
5 | [KDE](https://drive.google.com/open?id=1XTLxi0Wo8EVjqcTrqx73zGsmxkHjGuSd) | 388,711 | 399MB | 01/21/99 - 09/30/18
6 | [LibreOffice](https://drive.google.com/open?id=1ixqes8YiOt_EPAyX54EG3i3OKJ6URGbG) | 62,029 | 63MB | 08/03/10 - 09/30/18
7 | [Linux](https://drive.google.com/open?id=1pKwDW19lkPut1bFmEO8BzlRSh4z7pyDB) | 32,340 | 60MB | 11/06/02 - 09/30/18
8 | [LLVM](https://drive.google.com/open?id=1i_oV2G2Ade5FLqZiBOS_8fNw89_53L2Q) | 38,107| 31MB | 10/07/03 - 09/30/18
9 | [OpenOffice](https://drive.google.com/open?id=1N7eByW7NwpkYuu-MvBBWeMzDwfwRoA2f) | 127,797 | 85MB | 10/16/00- 09/30/18
&nbsp; |  Total | 2,038,675 | 1.86GB | &nbsp;
